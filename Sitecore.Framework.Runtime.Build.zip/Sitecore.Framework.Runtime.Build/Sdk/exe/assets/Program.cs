// © 2018 Sitecore Corporation A/S. All rights reserved. Sitecore® is a registered trademark of Sitecore Corporation A/S.
using System.Threading.Tasks;
using Sitecore.Framework.Runtime.Commands;

namespace Sitecore
{
    /// <summary>
    /// Encapsulates entry logic for the Sitecore runtime.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Entrypoint for the application.
        /// </summary>
        /// <param name="args">The arguments to be processed.</param>
        /// <returns>The return result of the invoked command.</returns>
        public static Task<int> Main(string[] args) => SitecoreHostCommand.InvokeAsync(args);
    }
}
